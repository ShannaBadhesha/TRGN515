# Liver Cirrhosis Prediction

## Shanna Badhesha 

![Stages_of_liver_damage_image.jpeg](attachment:719afbfc-eb17-49e4-879e-672a1337225e.jpeg)

## Table of Contents

- [Introduction](#Introduction)
- [Import Libraries](#Import-Libraries)
- [Dataset](#Dataset)
- [Data Preprocessing](#Data-Preprocessing)
- [Model Selection](#Model-Selection)
- [Conclusion](#Conclusion)
- [References](#References)

## Introduction

Liver cirrhosis is severe scarring of the liver that is caused by conditions such as hepatitis B and C infections, excessive alcohol consumption, non-alcoholic fatty liver disease and autoimmune hepatitis. Although liver cirrhosis is not reversible, early diagnosis of it can stop further cirrhosis [[1]](https://www.mayoclinic.org/diseases-conditions/cirrhosis/symptoms-causes/syc-20351487). About 4.5 million adults have been diagnosed in the United States, but it is suspected that 80-100 million undiagnosed adults have some form of liver disease that can cause cirrhosis [[2]](https://www.cdc.gov/nchs/fastats/liver-disease.htm). 

There are 4 stages of liver disease[[1]](https://www.mayoclinic.org/diseases-conditions/cirrhosis/symptoms-causes/syc-20351487). 
- Stage 1: Beginning of liver disease where there is some inflammation of the liver. This stage is reversible with proper treatment. 
- Stage 2: Moderate Liver Damage where there is some scar tissue forming. This stage is reversible with proper treatment 
- Stage 3: Significant Liver Damage where there is a significant amount of scarred tissue. This stage may be reversible. 
- Stage 4: Severe Liver Damage (Cirrhosis)

The dataset I am using for my model can be found in the book "Counting Processes and Survival Analysis" by Thomas R. Fleming and David P. Harrington. It is also stored on Kaggle [[3]](https://www.kaggle.com/datasets/fedesoriano/cirrhosis-prediction-dataset). The study was conducted between 1974 and 1984 and contains 424 patients. Six patients were lost to follow up. 106 patients did not participate in the study, but did agree to taking basic measurements [[4]](https://onlinelibrary.wiley.com/doi/epdf/10.1002/9781118150672.app4). 

Certain factors can be used as indicators for stages of liver disease. 
- Sex: Men are twice as likely to have liver cirrhosis because they are more likely to have hepatitis and consume more alcohol in general [[5]](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3992057/).
- Ascites: refers to fluid accumulation in the peritoneal cavity. It is a common complication of liver cirrhosis and takes on average 10 years to develop. 80% of ascites cases are caused by cirrhosis [[6]](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3860926/). 
- Hepatomegaly: refers to an enlarged liver and can be an indicator of liver disease or cirrhosis [[7]](https://www.mayoclinic.org/diseases-conditions/enlarged-liver/symptoms-causes/syc-20372167).
- Spiders: can indicate an underlying disease such as cirrhosis or arthritis. About 33% of those with cirrhosis have spiders [[8]](https://www.ncbi.nlm.nih.gov/books/NBK507818/)
- Edema: liver cirrhosis can slow the flow of blood in the liver which can then lead to swelling in the legs and abdomen, called edema. This will happen to about 50% of people diagnosed within 10 years of being diagnosed with liver cirrhosis [[9]](https://academic.oup.com/qjmed/article/101/2/71/1601382). 
- Bilirubin: elevated levels of bilirubin can be indicative of liver cirrhosis. Total levels are normally around 0.1 to 1.2 mg/dL [[10]](https://www.ncbi.nlm.nih.gov/books/NBK548598/). 
- Cholesterol: high levels of cholesterol can lead to fatty liver disease which can eventually cause cirrhosis. The normal range for total cholestrol is less than 170mg/dL [[11]](https://keck.usc.edu/high-cholesterol-leads-to-long-term-liver-scarring-and-immune-cell-dysfunction-in-lab-study/#:~:text=Excess%20cholesterol%20accelerates%20damage%20of,of%20Medicine%20of%20USC%20research&text=There's%20a%20long%2Destablished%20link,as%20cirrhosis%20and%20liver%20cancer.). 
- Albumin: levels will decrease as cirrhosis gets worse. The normal range is 3.4 to 5.4 g/dL (34 to 54 g/L) [[12]](https://www.elsevier.es/en-revista-annals-hepatology-16-articulo-position-statement-on-the-use-S1665268122000503). 
- Copper: excess amounts of copper leads to liver damage and as the liver tries to repair itself, cirrhosis forms. The normal range is 62 to 140 micrograms per deciliter (mcg/dL) [[13]](https://www.mayoclinic.org/diseases-conditions/wilsons-disease/symptoms-causes/syc-20353251#:~:text=Scarring%20of%20the%20liver%20(cirrhosis,for%20the%20liver%20to%20function.). 
- Alk_Phos: high levels of this indicate a blockage in the bilary tract. It is not a director indicator of liver cirrhosis though [[14]](https://www.hepatitis.va.gov/hcv/patient/diagnosis/labtests-alkaline-phosphatase.asp).
- SGOT: this is an enzyme created by the liver. When the liver is damaged, SGOT can leak into the bloodstream. High levels of SGOT can be an indictor of liver damage. There are some people with cirrhosis, but normal SGOT levels. The normal range is 8 and 45 units per liter of serum [[15]](https://www.hepatitis.va.gov/hcv/patient/diagnosis/labtests-AST.asp). 
- Triglycerides: high amounts indicate fatty liver which may eventually lead to liver cirrhosis [[16]](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4213382/). 
- Platelets: low platelet counts can be an indictor of liver cirrhosis. Lower levels would indicate worse liver cirrhosis. The normal range is 50,000 to 450,000 platelets per microliter of blood [[17]](https://ashpublications.org/hematology/article/2022/1/296/493505/Thrombocytopenia-and-liver-disease-pathophysiology). 
- Prothrombin: high levels of this indicate liver cirrhosis. When the liver is damaged, it cannot make the appropriate amount of blood clotting proteins [[18]](https://www.hepatitis.va.gov/hcv/patient/diagnosis/labtests-prothrombin-time.asp#:~:text=When%20the%20PT%20is%20high,serious%20liver%20damage%20or%20cirrhosis.). 
- D-penicillamine: this can stop fibrogenesis and decreased incidence of scar lesions in the liver [[19]](https://pubmed.ncbi.nlm.nih.gov/19338486/#:~:text=D%2Dpenicillamine%20primarily%20can%20inhibit,scar%20lesions%20in%20the%20liver.). 

Liver cirrhosis can be life threatening if left untreated. Predicting the stage of liver cirrhosis can help guide medical management and determine appropriate interventions to manage complications. Using this dataset, I examined the features correlation and distribution to determine which would be best in predicting stages of liver cirrhosis. 

This model was completed using python in the jupyter notebook. 

Below is a step-by-step explanation of the model I created to predict liver cirrhosis using clinical symptoms, laboratory results, demographics and treatment. 

## Import Libraries

Begin by loading in the necessary libraries.


```python
%matplotlib inline
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
import imblearn as imblearn
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import cross_val_score
from imblearn import over_sampling
from imblearn.over_sampling import SMOTE
from collections import Counter
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import RandomizedSearchCV
from scipy.stats import randint
```

# Dataset

## Load the Dataset

Load in the dataset that we will be using. It can be downloaded from the Kaggle link listed in the introduction section. In this case, my csv was stored under the datasets directory in my environment. The df.head() command will show us the first 5 rows of the dataset. 


```python
df = pd.read_csv('../datasets/cirrhosis.csv')
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>N_Days</th>
      <th>Status</th>
      <th>Drug</th>
      <th>Age</th>
      <th>Sex</th>
      <th>Ascites</th>
      <th>Hepatomegaly</th>
      <th>Spiders</th>
      <th>Edema</th>
      <th>Bilirubin</th>
      <th>Cholesterol</th>
      <th>Albumin</th>
      <th>Copper</th>
      <th>Alk_Phos</th>
      <th>SGOT</th>
      <th>Tryglicerides</th>
      <th>Platelets</th>
      <th>Prothrombin</th>
      <th>Stage</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>400</td>
      <td>D</td>
      <td>D-penicillamine</td>
      <td>21464</td>
      <td>F</td>
      <td>Y</td>
      <td>Y</td>
      <td>Y</td>
      <td>Y</td>
      <td>14.5</td>
      <td>261.0</td>
      <td>2.60</td>
      <td>156.0</td>
      <td>1718.0</td>
      <td>137.95</td>
      <td>172.0</td>
      <td>190.0</td>
      <td>12.2</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>4500</td>
      <td>C</td>
      <td>D-penicillamine</td>
      <td>20617</td>
      <td>F</td>
      <td>N</td>
      <td>Y</td>
      <td>Y</td>
      <td>N</td>
      <td>1.1</td>
      <td>302.0</td>
      <td>4.14</td>
      <td>54.0</td>
      <td>7394.8</td>
      <td>113.52</td>
      <td>88.0</td>
      <td>221.0</td>
      <td>10.6</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>1012</td>
      <td>D</td>
      <td>D-penicillamine</td>
      <td>25594</td>
      <td>M</td>
      <td>N</td>
      <td>N</td>
      <td>N</td>
      <td>S</td>
      <td>1.4</td>
      <td>176.0</td>
      <td>3.48</td>
      <td>210.0</td>
      <td>516.0</td>
      <td>96.10</td>
      <td>55.0</td>
      <td>151.0</td>
      <td>12.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>1925</td>
      <td>D</td>
      <td>D-penicillamine</td>
      <td>19994</td>
      <td>F</td>
      <td>N</td>
      <td>Y</td>
      <td>Y</td>
      <td>S</td>
      <td>1.8</td>
      <td>244.0</td>
      <td>2.54</td>
      <td>64.0</td>
      <td>6121.8</td>
      <td>60.63</td>
      <td>92.0</td>
      <td>183.0</td>
      <td>10.3</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>1504</td>
      <td>CL</td>
      <td>Placebo</td>
      <td>13918</td>
      <td>F</td>
      <td>N</td>
      <td>Y</td>
      <td>Y</td>
      <td>N</td>
      <td>3.4</td>
      <td>279.0</td>
      <td>3.53</td>
      <td>143.0</td>
      <td>671.0</td>
      <td>113.15</td>
      <td>72.0</td>
      <td>136.0</td>
      <td>10.9</td>
      <td>3.0</td>
    </tr>
  </tbody>
</table>
</div>



Below is some information of the 20 attributes[[3]](https://www.kaggle.com/datasets/fedesoriano/cirrhosis-prediction-dataset): 

1) ID: identifier
2) N_Days: number of days between registration and the earlier of death, transplantation, or study analysis time in July 1986
3) Status: patient status 
    - C (censored)
    - CL (censored due to liver tx)
    - D (death)
4) Drug: drug type 
    - D-penicillamine 
    - placebo
5) Age: age in (days)
6) Sex: 
    - M (male) 
    - F (female)
7) Ascites: presence of ascites 
    - N (No) 
    - Y (Yes)
8) Hepatomegaly: presence of hepatomegaly 
    - N (No) 
    - Y (Yes)
9) Spiders: presence of spiders 
    - N (No) 
    - Y (Yes)
10) Edema: presence of edema 
    - N (no edema and no diuretic therapy for edema) 
    - S (edema present without diuretics, or edema resolved by diuretics)
    - Y (edema despite diuretic therapy)
11) Bilirubin: measured in (mg/dl)
12) Cholesterol: measured in (mg/dl)
13) Albumin: measured in (mg/dl)
14) Copper: measured in (ug/day)
15) Alk_Phos: measured in (U/liter)
16) SGOT: measured in (U/ml)
17) Triglycerides: measured in (mg/dl)
18) Platelets: platelets per cubic (ml/1000)
19) Prothrombin: prothrombin time in seconds (s)
20) Stage: histologic stage of disease (1, 2, 3, or 4) 
    - This will be the target in our model. Stages 1-3 will represent no cirrhosis and stage 4 will represent cirrhosis. 

## Exploring the dataset

Start exploring the dataset. In this section, we will analyze the correlation, data type, distribution and missing values. 


```python
df.shape
```




    (418, 20)



'df.shape' shows us the number of rows and columns respectively. There are 418 rows and 20 columns. 


```python
duplicates = df[df.duplicated()]
print(duplicates)
```

    Empty DataFrame
    Columns: [ID, N_Days, Status, Drug, Age, Sex, Ascites, Hepatomegaly, Spiders, Edema, Bilirubin, Cholesterol, Albumin, Copper, Alk_Phos, SGOT, Tryglicerides, Platelets, Prothrombin, Stage]
    Index: []


By running the code above, we can check for duplicates. Since this returns an empty dataframe, there are no duplicates in our dataset that need to be addressed. 


```python
df.describe().T
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>mean</th>
      <th>std</th>
      <th>min</th>
      <th>25%</th>
      <th>50%</th>
      <th>75%</th>
      <th>max</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>ID</th>
      <td>418.0</td>
      <td>209.500000</td>
      <td>120.810458</td>
      <td>1.00</td>
      <td>105.2500</td>
      <td>209.50</td>
      <td>313.75</td>
      <td>418.00</td>
    </tr>
    <tr>
      <th>N_Days</th>
      <td>418.0</td>
      <td>1917.782297</td>
      <td>1104.672992</td>
      <td>41.00</td>
      <td>1092.7500</td>
      <td>1730.00</td>
      <td>2613.50</td>
      <td>4795.00</td>
    </tr>
    <tr>
      <th>Age</th>
      <td>418.0</td>
      <td>18533.351675</td>
      <td>3815.845055</td>
      <td>9598.00</td>
      <td>15644.5000</td>
      <td>18628.00</td>
      <td>21272.50</td>
      <td>28650.00</td>
    </tr>
    <tr>
      <th>Bilirubin</th>
      <td>418.0</td>
      <td>3.220813</td>
      <td>4.407506</td>
      <td>0.30</td>
      <td>0.8000</td>
      <td>1.40</td>
      <td>3.40</td>
      <td>28.00</td>
    </tr>
    <tr>
      <th>Cholesterol</th>
      <td>284.0</td>
      <td>369.510563</td>
      <td>231.944545</td>
      <td>120.00</td>
      <td>249.5000</td>
      <td>309.50</td>
      <td>400.00</td>
      <td>1775.00</td>
    </tr>
    <tr>
      <th>Albumin</th>
      <td>418.0</td>
      <td>3.497440</td>
      <td>0.424972</td>
      <td>1.96</td>
      <td>3.2425</td>
      <td>3.53</td>
      <td>3.77</td>
      <td>4.64</td>
    </tr>
    <tr>
      <th>Copper</th>
      <td>310.0</td>
      <td>97.648387</td>
      <td>85.613920</td>
      <td>4.00</td>
      <td>41.2500</td>
      <td>73.00</td>
      <td>123.00</td>
      <td>588.00</td>
    </tr>
    <tr>
      <th>Alk_Phos</th>
      <td>312.0</td>
      <td>1982.655769</td>
      <td>2140.388824</td>
      <td>289.00</td>
      <td>871.5000</td>
      <td>1259.00</td>
      <td>1980.00</td>
      <td>13862.40</td>
    </tr>
    <tr>
      <th>SGOT</th>
      <td>312.0</td>
      <td>122.556346</td>
      <td>56.699525</td>
      <td>26.35</td>
      <td>80.6000</td>
      <td>114.70</td>
      <td>151.90</td>
      <td>457.25</td>
    </tr>
    <tr>
      <th>Tryglicerides</th>
      <td>282.0</td>
      <td>124.702128</td>
      <td>65.148639</td>
      <td>33.00</td>
      <td>84.2500</td>
      <td>108.00</td>
      <td>151.00</td>
      <td>598.00</td>
    </tr>
    <tr>
      <th>Platelets</th>
      <td>407.0</td>
      <td>257.024570</td>
      <td>98.325585</td>
      <td>62.00</td>
      <td>188.5000</td>
      <td>251.00</td>
      <td>318.00</td>
      <td>721.00</td>
    </tr>
    <tr>
      <th>Prothrombin</th>
      <td>416.0</td>
      <td>10.731731</td>
      <td>1.022000</td>
      <td>9.00</td>
      <td>10.0000</td>
      <td>10.60</td>
      <td>11.10</td>
      <td>18.00</td>
    </tr>
    <tr>
      <th>Stage</th>
      <td>412.0</td>
      <td>3.024272</td>
      <td>0.882042</td>
      <td>1.00</td>
      <td>2.0000</td>
      <td>3.00</td>
      <td>4.00</td>
      <td>4.00</td>
    </tr>
  </tbody>
</table>
</div>



From this summary, we are able to see that some of these have a large range and standard deviation implying that the data may be skewed. We will address this below. 

### Data Types

'df.info()' lists the column names, the number of non-missing values and if the type data it is. 'int64' and 'float64' represent numerical data. 'Object' represents the categorical data.


```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 418 entries, 0 to 417
    Data columns (total 20 columns):
     #   Column         Non-Null Count  Dtype  
    ---  ------         --------------  -----  
     0   ID             418 non-null    int64  
     1   N_Days         418 non-null    int64  
     2   Status         418 non-null    object 
     3   Drug           312 non-null    object 
     4   Age            418 non-null    int64  
     5   Sex            418 non-null    object 
     6   Ascites        312 non-null    object 
     7   Hepatomegaly   312 non-null    object 
     8   Spiders        312 non-null    object 
     9   Edema          418 non-null    object 
     10  Bilirubin      418 non-null    float64
     11  Cholesterol    284 non-null    float64
     12  Albumin        418 non-null    float64
     13  Copper         310 non-null    float64
     14  Alk_Phos       312 non-null    float64
     15  SGOT           312 non-null    float64
     16  Tryglicerides  282 non-null    float64
     17  Platelets      407 non-null    float64
     18  Prothrombin    416 non-null    float64
     19  Stage          412 non-null    float64
    dtypes: float64(10), int64(3), object(7)
    memory usage: 65.4+ KB



```python
num_cols = df.select_dtypes(include=['int64', 'float64']).columns
num_cols
```




    Index(['ID', 'N_Days', 'Age', 'Bilirubin', 'Cholesterol', 'Albumin', 'Copper',
           'Alk_Phos', 'SGOT', 'Tryglicerides', 'Platelets', 'Prothrombin',
           'Stage'],
          dtype='object')




```python
cat_cols = df.select_dtypes(include=['object']).columns
cat_cols
```




    Index(['Status', 'Drug', 'Sex', 'Ascites', 'Hepatomegaly', 'Spiders', 'Edema'], dtype='object')



Numerical:
- ID
- N_Days
- Age
- Bilirubin
- Cholesterol
- albumin
- copper
- alk_phos
- SGOT
- Triglycerides
- Platelets
- Prothrombin
- Stage (target)

Categorical: 
- Status
- Drug
- Sex
- Ascites
- Hepatomegaly
- Spiders
- Edema

# Data Preprocessing

### Missing Values


```python
df.isnull().sum()
```




    ID                 0
    N_Days             0
    Status             0
    Drug             106
    Age                0
    Sex                0
    Ascites          106
    Hepatomegaly     106
    Spiders          106
    Edema              0
    Bilirubin          0
    Cholesterol      134
    Albumin            0
    Copper           108
    Alk_Phos         106
    SGOT             106
    Tryglicerides    136
    Platelets         11
    Prothrombin        2
    Stage              6
    dtype: int64



From the non-null count column above, we can see that there are some missing values since they do not all equal 418. We will calculate the number of missing values in the dataset. We see that about 25% of the data is missing for 9 columns. Since it makes up such a large portion of our dataset and it is already a small dataset, we can't remove the rows with the missing data. 

We will go through each of the attributes in the dataset and decide how to deal with the null values. 

#### 1. ID: 


```python
df['ID'].isnull().sum()
```




    0



There are no missing values in the ID column. Since we already checked if there are any duplicates we can remove this column. It will not be useful for our model.

#### 2. N_days: 


```python
df['N_Days'].isnull().sum()
```




    0



This attribute may be useful in analyzing the survival of patients with liver disease but not predicting different stages of liver disease. It will not help with our question and will be removed. 

#### 3. Status: 


```python
df['Status'].isnull().sum()
```




    0



For the same reason mentioned above, we will remove this feature. 

#### 4. Drug: 


```python
df['Drug'].isnull().sum()
```




    106




```python
df['Drug'].dtype.name
```




    'object'




```python
plt.figure(figsize=(12,6))
sns.countplot(x= df["Drug"], palette="pastel")
plt.xlabel('Drug')
plt.ylabel('Count');
```


    
![png](output_46_0.png)
    


This is a categorical attribute. We will use the mode to fill in the null values. 

#### 5. Age: 


```python
df['Age'].isnull().sum()
```




    0




```python
df['Age'].dtype.name
```




    'int64'



There are no missing values for this attribute, but the values are listed in days. We will convert the days to years in a later step. 

#### 6. Sex: 


```python
df['Sex'].isnull().sum()
```




    0



There is no missing data for this attribute. 

#### 7. Ascites: 


```python
df['Ascites'].isnull().sum()
```




    106




```python
df['Ascites'].dtype.name
```




    'object'




```python
plt.figure(figsize=(12,6))
sns.countplot(x= df["Ascites"], palette="pastel")
plt.xlabel('Ascites')
plt.ylabel('Count');
```


    
![png](output_58_0.png)
    


This is a categorical attribute. There are 106 missing values. To replace these, we will use the mode. 

#### 8. Hepatomegaly: 


```python
df['Hepatomegaly'].isnull().sum()
```




    106




```python
df['Hepatomegaly'].dtype.name
```




    'object'




```python
plt.figure(figsize=(12,6))
sns.countplot(x= df["Hepatomegaly"], palette="pastel")
plt.xlabel('Hepatomegaly')
plt.ylabel('Count');
```


    
![png](output_63_0.png)
    


This is a categorical attribute. There are 106 missing values. To replace these, we will use the mode. 

#### 9. Spiders: 


```python
df['Spiders'].isnull().sum()
```




    106




```python
df['Spiders'].dtype.name
```




    'object'




```python
plt.figure(figsize=(12,6))
sns.countplot(x= df["Spiders"], palette="pastel")
plt.xlabel('Spiders')
plt.ylabel('Count');
```


    
![png](output_68_0.png)
    


This is a categorical attribute. There are 106 missing values. To replace these, we will use the mode. 

#### 10. Edema: 


```python
df['Edema'].isnull().sum()
```




    0



There is no missing data for this attribute. 

#### 11. Bilirubin: 


```python
df['Bilirubin'].isnull().sum()
```




    0



There is no missing data for this attribute. 

#### 12. Cholesterol: 


```python
df['Cholesterol'].isnull().sum()
```




    134




```python
df['Cholesterol'].dtype.name
```




    'float64'




```python
fig, (ax1, ax2) = plt.subplots(ncols=2, figsize=(12, 6))
sns.set(style="whitegrid", palette="pastel")
sns.boxplot(data=df, x='Cholesterol', ax=ax1)
ax1.set(title='Boxplot of Cholesterol')

sns.histplot(data=df, x='Cholesterol', ax=ax2)
ax2.set(title='Histogram of Cholesterol')

plt.show()
```


    
![png](output_79_0.png)
    


There are 134 missing values for this attribute. It is a numerical category, so we can either use the mean or median to replace the missing values in this category. I used a boxplot and histogram to evaluate the distribution. Since the data is skewed, it will be best to use the median to replace the missing values. The median is not as sensitive to outliers as the mean is. 

#### 13. Albumin: 


```python
df['Albumin'].isnull().sum()
```




    0



There is no missing data for this attribute. 

#### 14. Copper: 


```python
df['Copper'].isnull().sum()
```




    108




```python
df['Copper'].dtype.name
```




    'float64'




```python
fig, (ax1, ax2) = plt.subplots(ncols=2, figsize=(12, 6))
sns.set(style="whitegrid", palette="pastel")
sns.boxplot(data=df, x='Copper', ax=ax1)
ax1.set(title='Boxplot of Copper')

sns.histplot(data=df, x='Copper', ax=ax2)
ax2.set(title='Histogram of Copper')

plt.show()
```


    
![png](output_87_0.png)
    


There are 108 missing values for this attribute. It is a numerical category, so we can either use the mean or median to replace the missing values in this category. I used a boxplot and histogram to evaluate the distribution. Since the data is skewed, it will be best to use the median to replace the missing values. The median is not as sensitive to outliers as the mean is. 

#### 15. Alk_phos: 


```python
df['Alk_Phos'].isnull().sum()
```




    106




```python
df['Alk_Phos'].dtype.name
```




    'float64'




```python
fig, (ax1, ax2) = plt.subplots(ncols=2, figsize=(12, 6))
sns.set(style="whitegrid", palette="pastel")
sns.boxplot(data=df, x='Alk_Phos', ax=ax1)
ax1.set(title='Boxplot of Alk_Phos')

sns.histplot(data=df, x='Alk_Phos', ax=ax2)
ax2.set(title='Histogram of Alk_Phos')

plt.show()
```


    
![png](output_92_0.png)
    


There are 106 missing values for this attribute. It is a numerical category, so we can either use the mean or median to replace the missing values in this category. I used a boxplot and histogram to evaluate the distribution. Since the data is skewed, it will be best to use the median to replace the missing values. The median is not as sensitive to outliers as the mean is. 

#### 16. SGOT: 


```python
df['SGOT'].isnull().sum()
```




    106




```python
df['SGOT'].dtype.name
```




    'float64'




```python
fig, (ax1, ax2) = plt.subplots(ncols=2, figsize=(12, 6))
sns.set(style="whitegrid", palette="pastel")
sns.boxplot(data=df, x='SGOT', ax=ax1)
ax1.set(title='Boxplot of SGOT')

sns.histplot(data=df, x='SGOT', ax=ax2)
ax2.set(title='Histogram of SGOT')

plt.show()
```


    
![png](output_97_0.png)
    


There are 106 missing values for this attribute. It is a numerical category, so we can either use the mean or median to replace the missing values in this category. I used a boxplot and histogram to evaluate the distribution. Since the data is skewed, it will be best to use the median to replace the missing values. The median is not as sensitive to outliers as the mean is. 

#### 17. Triglycerides: 


```python
df['Tryglicerides'].isnull().sum()
```




    136




```python
df['Tryglicerides'].dtype.name
```




    'float64'




```python
fig, (ax1, ax2) = plt.subplots(ncols=2, figsize=(12, 6))
sns.set(style="whitegrid", palette="pastel")
sns.boxplot(data=df, x='Tryglicerides', ax=ax1)
ax1.set(title='Boxplot of Tryglicerides')

sns.histplot(data=df, x='Tryglicerides', ax=ax2)
ax2.set(title='Histogram of Tryglicerides')

plt.show()
```


    
![png](output_102_0.png)
    


There are 136 missing values for this attribute. It is a numerical category, so we can either use the mean or median to replace the missing values in this category. I used a boxplot and histogram to evaluate the distribution. Since the data is skewed, it will be best to use the median to replace the missing values. The median is not as sensitive to outliers as the mean is. 

#### 18. Platelets: 


```python
df['Platelets'].isnull().sum()
```




    11




```python
df['Platelets'].dtype.name
```




    'float64'




```python
fig, (ax1, ax2) = plt.subplots(ncols=2, figsize=(12, 6))
sns.set(style="whitegrid", palette="pastel")
sns.boxplot(data=df, x='Platelets', ax=ax1)
ax1.set(title='Boxplot of Platelets')

sns.histplot(data=df, x='Platelets', ax=ax2)
ax2.set(title='Histogram of Platelets')

plt.show()
```


    
![png](output_107_0.png)
    


There are 11 missing values for this attribute. It is a numerical category, so we can either use the mean or median to replace the missing values in this category. I used a boxplot and histogram to evaluate the distribution. Since the data is skewed, it will be best to use the median to replace the missing values. The median is not as sensitive to outliers as the mean is. 

#### 19. Prothrombin: 


```python
df['Prothrombin'].isnull().sum()
```




    2




```python
df['Prothrombin'].dtype.name
```




    'float64'




```python
fig, (ax1, ax2) = plt.subplots(ncols=2, figsize=(12, 6))
sns.set(style="whitegrid", palette="pastel")
sns.boxplot(data=df, x='Prothrombin', ax=ax1)
ax1.set(title='Boxplot of Prothrombin')

sns.histplot(data=df, x='Prothrombin', ax=ax2)
ax2.set(title='Histogram of Prothrombin')

plt.show()
```


    
![png](output_112_0.png)
    


There are 2 missing values for this attribute. It is a numerical category, so we can either use the mean or median to replace the missing values in this category. I used a boxplot and histogram to evaluate the distribution. Since the data is skewed, it will be best to use the median to replace the missing values. The median is not as sensitive to outliers as the mean is. 

#### 20. Stage(Target):


```python
df['Stage'].isnull().sum()
```




    6



There are only 6 missing values in our target data which is about 1.4% of our total data. I decided to remove the missing values.

### Handling missing values

In this section, the following will be done: 

- Remove the "ID", "N_Days", and "Status" column
- Remove the row with missing values from the "Stage" column
- Replace the missing values in the categorical data with the mode
- Replace the missing values in the numerical data with the median


```python
#Remove the "ID", "N_Days", and "Status" column
df_copy = df.copy()
df2 = df_copy.drop(["ID","N_Days","Status"],axis=1)
df2.shape
```




    (418, 17)




```python
#Remove the row with missing values from the "Stage" column

df2 = df2.dropna(subset=['Stage'])
df2.shape
```




    (412, 17)




```python
#Replace the missing values in the categorical data with the mode

for col in df2.select_dtypes(include='object').columns:
    if df2[col].isnull().sum() > 0:
        mode_val = df2[col].mode()[0]
        df2[col].fillna(mode_val, inplace=True)
```


```python
df2.isnull().sum()
```




    Drug               0
    Age                0
    Sex                0
    Ascites            0
    Hepatomegaly       0
    Spiders            0
    Edema              0
    Bilirubin          0
    Cholesterol      128
    Albumin            0
    Copper           102
    Alk_Phos         100
    SGOT             100
    Tryglicerides    130
    Platelets         11
    Prothrombin        2
    Stage              0
    dtype: int64




```python
#Replace the missing values in the numerical data with the median

for col in df2.columns:
    if df2[col].dtype in ['float64', 'int64']:
        df2[col].fillna(df2[col].median(), inplace=True)
```


```python
df2.isnull().sum()
```




    Drug             0
    Age              0
    Sex              0
    Ascites          0
    Hepatomegaly     0
    Spiders          0
    Edema            0
    Bilirubin        0
    Cholesterol      0
    Albumin          0
    Copper           0
    Alk_Phos         0
    SGOT             0
    Tryglicerides    0
    Platelets        0
    Prothrombin      0
    Stage            0
    dtype: int64



### Convert ['Age'] from days to years

We will convert the age column from days to years to be consisten and use the standard unit of measurement for Age. This will make it easier to understand and interpret data.


```python
df2['Age'] = (df2['Age'] / 365.25).round()
df2.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Drug</th>
      <th>Age</th>
      <th>Sex</th>
      <th>Ascites</th>
      <th>Hepatomegaly</th>
      <th>Spiders</th>
      <th>Edema</th>
      <th>Bilirubin</th>
      <th>Cholesterol</th>
      <th>Albumin</th>
      <th>Copper</th>
      <th>Alk_Phos</th>
      <th>SGOT</th>
      <th>Tryglicerides</th>
      <th>Platelets</th>
      <th>Prothrombin</th>
      <th>Stage</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>D-penicillamine</td>
      <td>59.0</td>
      <td>F</td>
      <td>Y</td>
      <td>Y</td>
      <td>Y</td>
      <td>Y</td>
      <td>14.5</td>
      <td>261.0</td>
      <td>2.60</td>
      <td>156.0</td>
      <td>1718.0</td>
      <td>137.95</td>
      <td>172.0</td>
      <td>190.0</td>
      <td>12.2</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>D-penicillamine</td>
      <td>56.0</td>
      <td>F</td>
      <td>N</td>
      <td>Y</td>
      <td>Y</td>
      <td>N</td>
      <td>1.1</td>
      <td>302.0</td>
      <td>4.14</td>
      <td>54.0</td>
      <td>7394.8</td>
      <td>113.52</td>
      <td>88.0</td>
      <td>221.0</td>
      <td>10.6</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>D-penicillamine</td>
      <td>70.0</td>
      <td>M</td>
      <td>N</td>
      <td>N</td>
      <td>N</td>
      <td>S</td>
      <td>1.4</td>
      <td>176.0</td>
      <td>3.48</td>
      <td>210.0</td>
      <td>516.0</td>
      <td>96.10</td>
      <td>55.0</td>
      <td>151.0</td>
      <td>12.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>D-penicillamine</td>
      <td>55.0</td>
      <td>F</td>
      <td>N</td>
      <td>Y</td>
      <td>Y</td>
      <td>S</td>
      <td>1.8</td>
      <td>244.0</td>
      <td>2.54</td>
      <td>64.0</td>
      <td>6121.8</td>
      <td>60.63</td>
      <td>92.0</td>
      <td>183.0</td>
      <td>10.3</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Placebo</td>
      <td>38.0</td>
      <td>F</td>
      <td>N</td>
      <td>Y</td>
      <td>Y</td>
      <td>N</td>
      <td>3.4</td>
      <td>279.0</td>
      <td>3.53</td>
      <td>143.0</td>
      <td>671.0</td>
      <td>113.15</td>
      <td>72.0</td>
      <td>136.0</td>
      <td>10.9</td>
      <td>3.0</td>
    </tr>
  </tbody>
</table>
</div>



### Correlated Data

By using a heatmap, we will be able to determine if any of the numerical features are highly correlated with each other or the target. This will help us decide if any of the features need to be removed. 


```python
df2.corr()

plt.figure(figsize=(20,8))
sns.heatmap(df2.corr());
```


    
![png](output_130_0.png)
    


We will create another heatmap that includes the correlation coefficients for better visualization. 


```python
corr2 = df2.corr().round(2)

# Mask for the upper triangle
mask = np.zeros_like(corr2, dtype=np.bool)
mask[np.triu_indices_from(mask)] = True

# Set figure size
f, ax = plt.subplots(figsize=(20, 20))

# Define custom colormap
cmap = sns.diverging_palette(220, 10, as_cmap=True)

# Draw the heatmap
sns.heatmap(corr2, mask=mask, cmap=cmap,
            square=True, linewidths=.5, cbar_kws={"shrink": .5}, annot=True)

plt.tight_layout()
```


    
![png](output_132_0.png)
    


Based off this heatmap, none of the features are highly correlated with each other. I have decided to not take out any features at this point since none of them are highly correlated. We can also use a pairplot to determine if any of the features are highly correlated and need to be removed.  

### Label Encoding

This process is to assign unique numerical labels to each category in a categorical column. This is done because machine learning projects require numerical values. 


```python
df2.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Drug</th>
      <th>Age</th>
      <th>Sex</th>
      <th>Ascites</th>
      <th>Hepatomegaly</th>
      <th>Spiders</th>
      <th>Edema</th>
      <th>Bilirubin</th>
      <th>Cholesterol</th>
      <th>Albumin</th>
      <th>Copper</th>
      <th>Alk_Phos</th>
      <th>SGOT</th>
      <th>Tryglicerides</th>
      <th>Platelets</th>
      <th>Prothrombin</th>
      <th>Stage</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>D-penicillamine</td>
      <td>59.0</td>
      <td>F</td>
      <td>Y</td>
      <td>Y</td>
      <td>Y</td>
      <td>Y</td>
      <td>14.5</td>
      <td>261.0</td>
      <td>2.60</td>
      <td>156.0</td>
      <td>1718.0</td>
      <td>137.95</td>
      <td>172.0</td>
      <td>190.0</td>
      <td>12.2</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>D-penicillamine</td>
      <td>56.0</td>
      <td>F</td>
      <td>N</td>
      <td>Y</td>
      <td>Y</td>
      <td>N</td>
      <td>1.1</td>
      <td>302.0</td>
      <td>4.14</td>
      <td>54.0</td>
      <td>7394.8</td>
      <td>113.52</td>
      <td>88.0</td>
      <td>221.0</td>
      <td>10.6</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>D-penicillamine</td>
      <td>70.0</td>
      <td>M</td>
      <td>N</td>
      <td>N</td>
      <td>N</td>
      <td>S</td>
      <td>1.4</td>
      <td>176.0</td>
      <td>3.48</td>
      <td>210.0</td>
      <td>516.0</td>
      <td>96.10</td>
      <td>55.0</td>
      <td>151.0</td>
      <td>12.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>D-penicillamine</td>
      <td>55.0</td>
      <td>F</td>
      <td>N</td>
      <td>Y</td>
      <td>Y</td>
      <td>S</td>
      <td>1.8</td>
      <td>244.0</td>
      <td>2.54</td>
      <td>64.0</td>
      <td>6121.8</td>
      <td>60.63</td>
      <td>92.0</td>
      <td>183.0</td>
      <td>10.3</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Placebo</td>
      <td>38.0</td>
      <td>F</td>
      <td>N</td>
      <td>Y</td>
      <td>Y</td>
      <td>N</td>
      <td>3.4</td>
      <td>279.0</td>
      <td>3.53</td>
      <td>143.0</td>
      <td>671.0</td>
      <td>113.15</td>
      <td>72.0</td>
      <td>136.0</td>
      <td>10.9</td>
      <td>3.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
class MultiColumnLabelEncoder:
    def __init__(self,columns = None):
        self.columns = columns # array of column names to encode

    def fit(self,X,y=None):
        return self # not relevant here

    def transform(self,X):
        '''
        Transforms columns of X specified in self.columns using
        LabelEncoder(). If no columns specified, transforms all
        columns in X.
        '''
        output = X.copy()
        if self.columns is not None:
            for col in self.columns:
                output[col] = LabelEncoder().fit_transform(output[col])
        else:
            for colname,col in output.iteritems():
                output[colname] = LabelEncoder().fit_transform(col)
        return output

    def fit_transform(self,X,y=None):
        return self.fit(X,y).transform(X)
    
```


```python
df3 =MultiColumnLabelEncoder(columns = ['Drug','Sex', 'Ascites', 'Hepatomegaly', 'Spiders', 'Edema']).fit_transform(df2)
df3
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Drug</th>
      <th>Age</th>
      <th>Sex</th>
      <th>Ascites</th>
      <th>Hepatomegaly</th>
      <th>Spiders</th>
      <th>Edema</th>
      <th>Bilirubin</th>
      <th>Cholesterol</th>
      <th>Albumin</th>
      <th>Copper</th>
      <th>Alk_Phos</th>
      <th>SGOT</th>
      <th>Tryglicerides</th>
      <th>Platelets</th>
      <th>Prothrombin</th>
      <th>Stage</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>59.0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>14.5</td>
      <td>261.0</td>
      <td>2.60</td>
      <td>156.0</td>
      <td>1718.0</td>
      <td>137.95</td>
      <td>172.0</td>
      <td>190.0</td>
      <td>12.2</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>56.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1.1</td>
      <td>302.0</td>
      <td>4.14</td>
      <td>54.0</td>
      <td>7394.8</td>
      <td>113.52</td>
      <td>88.0</td>
      <td>221.0</td>
      <td>10.6</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>70.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1.4</td>
      <td>176.0</td>
      <td>3.48</td>
      <td>210.0</td>
      <td>516.0</td>
      <td>96.10</td>
      <td>55.0</td>
      <td>151.0</td>
      <td>12.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>55.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1.8</td>
      <td>244.0</td>
      <td>2.54</td>
      <td>64.0</td>
      <td>6121.8</td>
      <td>60.63</td>
      <td>92.0</td>
      <td>183.0</td>
      <td>10.3</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>38.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>3.4</td>
      <td>279.0</td>
      <td>3.53</td>
      <td>143.0</td>
      <td>671.0</td>
      <td>113.15</td>
      <td>72.0</td>
      <td>136.0</td>
      <td>10.9</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>413</th>
      <td>0</td>
      <td>67.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1.2</td>
      <td>309.5</td>
      <td>2.96</td>
      <td>73.0</td>
      <td>1259.0</td>
      <td>114.70</td>
      <td>108.0</td>
      <td>174.0</td>
      <td>10.9</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>414</th>
      <td>0</td>
      <td>39.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0.9</td>
      <td>309.5</td>
      <td>3.83</td>
      <td>73.0</td>
      <td>1259.0</td>
      <td>114.70</td>
      <td>108.0</td>
      <td>180.0</td>
      <td>11.2</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>415</th>
      <td>0</td>
      <td>57.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1.6</td>
      <td>309.5</td>
      <td>3.42</td>
      <td>73.0</td>
      <td>1259.0</td>
      <td>114.70</td>
      <td>108.0</td>
      <td>143.0</td>
      <td>9.9</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>416</th>
      <td>0</td>
      <td>58.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0.8</td>
      <td>309.5</td>
      <td>3.75</td>
      <td>73.0</td>
      <td>1259.0</td>
      <td>114.70</td>
      <td>108.0</td>
      <td>269.0</td>
      <td>10.4</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>417</th>
      <td>0</td>
      <td>53.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0.7</td>
      <td>309.5</td>
      <td>3.29</td>
      <td>73.0</td>
      <td>1259.0</td>
      <td>114.70</td>
      <td>108.0</td>
      <td>350.0</td>
      <td>10.6</td>
      <td>4.0</td>
    </tr>
  </tbody>
</table>
<p>412 rows × 17 columns</p>
</div>



### Class Imbalance


```python
plt.figure(figsize=(10,6))
sns.countplot(data=df3, x='Stage', palette="Set2")
plt.xlabel('Stage')
plt.ylabel('Count')
plt.show()
```


    
![png](output_140_0.png)
    



```python
df3['Stage'].value_counts()
```




    3.0    155
    4.0    144
    2.0     92
    1.0     21
    Name: Stage, dtype: int64



There is a clear imbalance issue in our target. There are 155 stage 3 counts, 144 stage 4 counts, 92 stage 2 counts and 21 stage 1 counts. Since this is already a small dataset, I will choose to implement random oversampling on the minority groups. I have decided to merge stages 1, 2, 3 and stage 4 will be liver cirrhosis. 1 is the ppl with liver cirrhosis and 0 is the ppl with stage 1-3. 


```python
df3['Stage'] = np.where(df3['Stage'] == 4, 1, 0)
```


```python
df3['Stage'].value_counts()
```




    0    268
    1    144
    Name: Stage, dtype: int64




```python
plt.figure(figsize=(10,6))
sns.countplot(data=df3, x='Stage', palette="Set2")
plt.xlabel('Stage')
plt.ylabel('Count')
plt.show()
```


    
![png](output_145_0.png)
    


#### Set up features and target


```python
X= df3.drop(['Stage'], axis = 1)
Y = df3['Stage']
```


```python
X
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Drug</th>
      <th>Age</th>
      <th>Sex</th>
      <th>Ascites</th>
      <th>Hepatomegaly</th>
      <th>Spiders</th>
      <th>Edema</th>
      <th>Bilirubin</th>
      <th>Cholesterol</th>
      <th>Albumin</th>
      <th>Copper</th>
      <th>Alk_Phos</th>
      <th>SGOT</th>
      <th>Tryglicerides</th>
      <th>Platelets</th>
      <th>Prothrombin</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>59.0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>14.5</td>
      <td>261.0</td>
      <td>2.60</td>
      <td>156.0</td>
      <td>1718.0</td>
      <td>137.95</td>
      <td>172.0</td>
      <td>190.0</td>
      <td>12.2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>56.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1.1</td>
      <td>302.0</td>
      <td>4.14</td>
      <td>54.0</td>
      <td>7394.8</td>
      <td>113.52</td>
      <td>88.0</td>
      <td>221.0</td>
      <td>10.6</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>70.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1.4</td>
      <td>176.0</td>
      <td>3.48</td>
      <td>210.0</td>
      <td>516.0</td>
      <td>96.10</td>
      <td>55.0</td>
      <td>151.0</td>
      <td>12.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>55.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1.8</td>
      <td>244.0</td>
      <td>2.54</td>
      <td>64.0</td>
      <td>6121.8</td>
      <td>60.63</td>
      <td>92.0</td>
      <td>183.0</td>
      <td>10.3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>38.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>3.4</td>
      <td>279.0</td>
      <td>3.53</td>
      <td>143.0</td>
      <td>671.0</td>
      <td>113.15</td>
      <td>72.0</td>
      <td>136.0</td>
      <td>10.9</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>413</th>
      <td>0</td>
      <td>67.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1.2</td>
      <td>309.5</td>
      <td>2.96</td>
      <td>73.0</td>
      <td>1259.0</td>
      <td>114.70</td>
      <td>108.0</td>
      <td>174.0</td>
      <td>10.9</td>
    </tr>
    <tr>
      <th>414</th>
      <td>0</td>
      <td>39.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0.9</td>
      <td>309.5</td>
      <td>3.83</td>
      <td>73.0</td>
      <td>1259.0</td>
      <td>114.70</td>
      <td>108.0</td>
      <td>180.0</td>
      <td>11.2</td>
    </tr>
    <tr>
      <th>415</th>
      <td>0</td>
      <td>57.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1.6</td>
      <td>309.5</td>
      <td>3.42</td>
      <td>73.0</td>
      <td>1259.0</td>
      <td>114.70</td>
      <td>108.0</td>
      <td>143.0</td>
      <td>9.9</td>
    </tr>
    <tr>
      <th>416</th>
      <td>0</td>
      <td>58.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0.8</td>
      <td>309.5</td>
      <td>3.75</td>
      <td>73.0</td>
      <td>1259.0</td>
      <td>114.70</td>
      <td>108.0</td>
      <td>269.0</td>
      <td>10.4</td>
    </tr>
    <tr>
      <th>417</th>
      <td>0</td>
      <td>53.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0.7</td>
      <td>309.5</td>
      <td>3.29</td>
      <td>73.0</td>
      <td>1259.0</td>
      <td>114.70</td>
      <td>108.0</td>
      <td>350.0</td>
      <td>10.6</td>
    </tr>
  </tbody>
</table>
<p>412 rows × 16 columns</p>
</div>




```python
Y
```




    0      1
    1      0
    2      1
    3      1
    4      0
          ..
    413    0
    414    1
    415    0
    416    0
    417    1
    Name: Stage, Length: 412, dtype: int64



## Deal with imbalanced dataset


```python
sm = SMOTE(k_neighbors = 4)
print('Original dataset shape %s' % Counter(Y))
X, Y = sm.fit_resample(X, Y)
print('Resampled dataset shape %s' % Counter(Y))
```

    Original dataset shape Counter({0: 268, 1: 144})
    Resampled dataset shape Counter({1: 268, 0: 268})



```python
X.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Drug</th>
      <th>Age</th>
      <th>Sex</th>
      <th>Ascites</th>
      <th>Hepatomegaly</th>
      <th>Spiders</th>
      <th>Edema</th>
      <th>Bilirubin</th>
      <th>Cholesterol</th>
      <th>Albumin</th>
      <th>Copper</th>
      <th>Alk_Phos</th>
      <th>SGOT</th>
      <th>Tryglicerides</th>
      <th>Platelets</th>
      <th>Prothrombin</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>59.0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>14.5</td>
      <td>261.0</td>
      <td>2.60</td>
      <td>156.0</td>
      <td>1718.0</td>
      <td>137.95</td>
      <td>172.0</td>
      <td>190.0</td>
      <td>12.2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>56.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1.1</td>
      <td>302.0</td>
      <td>4.14</td>
      <td>54.0</td>
      <td>7394.8</td>
      <td>113.52</td>
      <td>88.0</td>
      <td>221.0</td>
      <td>10.6</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>70.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1.4</td>
      <td>176.0</td>
      <td>3.48</td>
      <td>210.0</td>
      <td>516.0</td>
      <td>96.10</td>
      <td>55.0</td>
      <td>151.0</td>
      <td>12.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>55.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1.8</td>
      <td>244.0</td>
      <td>2.54</td>
      <td>64.0</td>
      <td>6121.8</td>
      <td>60.63</td>
      <td>92.0</td>
      <td>183.0</td>
      <td>10.3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>38.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>3.4</td>
      <td>279.0</td>
      <td>3.53</td>
      <td>143.0</td>
      <td>671.0</td>
      <td>113.15</td>
      <td>72.0</td>
      <td>136.0</td>
      <td>10.9</td>
    </tr>
  </tbody>
</table>
</div>




```python
Y.value_counts()
```




    1    268
    0    268
    Name: Stage, dtype: int64




```python
sns.countplot(x=Y)
plt.show()
```


    
![png](output_154_0.png)
    


### Set up Training and Testing datasets


```python
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.30, random_state=42)
print('X_train size: {}, X_test size: {}'.format(X_train.shape, X_test.shape))
```

    X_train size: (375, 16), X_test size: (161, 16)



```python
X_train.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Drug</th>
      <th>Age</th>
      <th>Sex</th>
      <th>Ascites</th>
      <th>Hepatomegaly</th>
      <th>Spiders</th>
      <th>Edema</th>
      <th>Bilirubin</th>
      <th>Cholesterol</th>
      <th>Albumin</th>
      <th>Copper</th>
      <th>Alk_Phos</th>
      <th>SGOT</th>
      <th>Tryglicerides</th>
      <th>Platelets</th>
      <th>Prothrombin</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>57</th>
      <td>0</td>
      <td>45.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.7</td>
      <td>242.0</td>
      <td>4.08</td>
      <td>73.0</td>
      <td>5890.0</td>
      <td>56.76</td>
      <td>118.0</td>
      <td>249.0</td>
      <td>10.6</td>
    </tr>
    <tr>
      <th>227</th>
      <td>1</td>
      <td>37.0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.7</td>
      <td>215.0</td>
      <td>3.35</td>
      <td>41.0</td>
      <td>645.0</td>
      <td>93.00</td>
      <td>74.0</td>
      <td>165.0</td>
      <td>9.6</td>
    </tr>
    <tr>
      <th>24</th>
      <td>1</td>
      <td>45.0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.7</td>
      <td>298.0</td>
      <td>4.10</td>
      <td>40.0</td>
      <td>661.0</td>
      <td>106.95</td>
      <td>66.0</td>
      <td>324.0</td>
      <td>11.3</td>
    </tr>
    <tr>
      <th>17</th>
      <td>0</td>
      <td>54.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>11.4</td>
      <td>178.0</td>
      <td>2.80</td>
      <td>588.0</td>
      <td>961.0</td>
      <td>280.55</td>
      <td>200.0</td>
      <td>283.0</td>
      <td>12.4</td>
    </tr>
    <tr>
      <th>210</th>
      <td>1</td>
      <td>53.0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.3</td>
      <td>309.5</td>
      <td>3.76</td>
      <td>27.0</td>
      <td>1282.0</td>
      <td>100.75</td>
      <td>108.0</td>
      <td>114.0</td>
      <td>10.3</td>
    </tr>
  </tbody>
</table>
</div>




```python
X_test.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Drug</th>
      <th>Age</th>
      <th>Sex</th>
      <th>Ascites</th>
      <th>Hepatomegaly</th>
      <th>Spiders</th>
      <th>Edema</th>
      <th>Bilirubin</th>
      <th>Cholesterol</th>
      <th>Albumin</th>
      <th>Copper</th>
      <th>Alk_Phos</th>
      <th>SGOT</th>
      <th>Tryglicerides</th>
      <th>Platelets</th>
      <th>Prothrombin</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>117</th>
      <td>0</td>
      <td>49.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3.5</td>
      <td>390.0</td>
      <td>3.30</td>
      <td>67.0</td>
      <td>878.0</td>
      <td>137.95</td>
      <td>93.0</td>
      <td>207.0</td>
      <td>10.2</td>
    </tr>
    <tr>
      <th>132</th>
      <td>1</td>
      <td>63.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.5</td>
      <td>331.0</td>
      <td>3.95</td>
      <td>13.0</td>
      <td>577.0</td>
      <td>128.65</td>
      <td>99.0</td>
      <td>165.0</td>
      <td>10.1</td>
    </tr>
    <tr>
      <th>154</th>
      <td>1</td>
      <td>44.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0.6</td>
      <td>220.0</td>
      <td>3.35</td>
      <td>57.0</td>
      <td>1620.0</td>
      <td>153.45</td>
      <td>80.0</td>
      <td>311.0</td>
      <td>11.2</td>
    </tr>
    <tr>
      <th>245</th>
      <td>0</td>
      <td>33.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2.1</td>
      <td>387.0</td>
      <td>3.77</td>
      <td>63.0</td>
      <td>1613.0</td>
      <td>150.35</td>
      <td>33.0</td>
      <td>185.0</td>
      <td>10.1</td>
    </tr>
    <tr>
      <th>84</th>
      <td>1</td>
      <td>47.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2.1</td>
      <td>262.0</td>
      <td>3.48</td>
      <td>58.0</td>
      <td>2045.0</td>
      <td>89.90</td>
      <td>84.0</td>
      <td>225.0</td>
      <td>11.5</td>
    </tr>
  </tbody>
</table>
</div>




```python
Y_train.head()
```




    57     0
    227    0
    24     0
    17     1
    210    0
    Name: Stage, dtype: int64




```python
Y_test .head()
```




    117    0
    132    1
    154    1
    245    1
    84     1
    Name: Stage, dtype: int64



### StandardScaler


```python
scaler = StandardScaler()

X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)
```

## Model Selection

Using GridSearchCV, we will determine what the best model for this dataset is. Using supervised learning algorithms. 


```python
lr_params = {'C': [0.1, 1, 10]}
dt_params = {'max_depth': [3, 5, 7], 'min_samples_split': [2, 5, 10]}
rf_params = {'n_estimators': [50, 100, 200], 'max_depth': [3, 5, 7], 'min_samples_split': [2, 5, 10]}
svm_params = {'C': [0.1, 1, 10], 'kernel': ['linear', 'rbf']}
knn_params = {'n_neighbors': [3, 5, 7], 'weights': ['uniform', 'distance']}
gb_params = {'n_estimators': [50, 100, 200], 'learning_rate': [0.01, 0.1, 1.0], 'max_depth': [3, 5, 7]}

models = {
    'Logistic Regression': (LogisticRegression(), lr_params),
    'Decision Tree': (DecisionTreeClassifier(), dt_params),
    'Random Forest': (RandomForestClassifier(), rf_params),
    'Support Vector Machine': (SVC(), svm_params),
    'K-Nearest Neighbors': (KNeighborsClassifier(), knn_params),
    'Gradient Boosting': (GradientBoostingClassifier(), gb_params),
}

model_names = []
train_acc_scores = []

for model_name, (model, params) in models.items():
    print('Training', model_name)
    grid = GridSearchCV(model, params, cv=5)
    grid.fit(X_train, Y_train)
    print('Best parameters:', grid.best_params_)
    print('Score:', grid.best_score_)
    
    model_names.append(model_name)
    train_acc_scores.append(grid.best_score_)
```

    Training Logistic Regression
    Best parameters: {'C': 0.1}
    Score: 0.6906666666666667
    Training Decision Tree
    Best parameters: {'max_depth': 3, 'min_samples_split': 2}
    Score: 0.6799999999999999
    Training Random Forest
    Best parameters: {'max_depth': 5, 'min_samples_split': 2, 'n_estimators': 100}
    Score: 0.7573333333333334
    Training Support Vector Machine
    Best parameters: {'C': 10, 'kernel': 'rbf'}
    Score: 0.7333333333333333
    Training K-Nearest Neighbors
    Best parameters: {'n_neighbors': 3, 'weights': 'distance'}
    Score: 0.7253333333333333
    Training Gradient Boosting
    Best parameters: {'learning_rate': 1.0, 'max_depth': 5, 'n_estimators': 200}
    Score: 0.7626666666666667



```python
plt.figure(figsize=(15,6))
sns.barplot(x=model_names, y=train_acc_scores, palette="Set2")
plt.xlabel('Model')
plt.ylabel('Scores')
plt.title('Scores for Different Models')
ax = plt.gca()
for i, score in enumerate(train_acc_scores):
    ax.text(i, score+0.01, '{:.3f}'.format(score), ha='center', va='bottom')

plt.show()
```


    
![png](output_166_0.png)
    


Gradient Boosting performed the best out of all the models. 


```python
best_model = GradientBoostingClassifier(learning_rate=1.0, max_depth=5, n_estimators=200)

best_model.fit(X_train, Y_train)

Y_pred = best_model.predict(X_test)

cm = confusion_matrix(Y_test, Y_pred)

train_acc_score = best_model.score(X_train, Y_train)
test_acc_score = best_model.score(X_test, Y_test)

plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt='g', cmap='Blues')
plt.xlabel('Predicted label')
plt.ylabel('True label')
plt.title(f'Testing Accuracy: {test_acc_score:.3f}\nTraining Accuracy: {train_acc_score:.3f}')
plt.show()
```


    
![png](output_168_0.png)
    


We will do some hyperparameter tuning here to see if we can improve our model. 


```python
param_dist = {
    'learning_rate': [0.01, 0.05, 0.1, 0.5, 1],
    'n_estimators': randint(50, 1000),
    'max_depth': [2, 3, 4, 5, None],
    'min_samples_split': randint(2, 11),
    'min_samples_leaf': randint(1, 11),
    'max_features': ['sqrt', 'log2', None]
}

clf = GradientBoostingClassifier(random_state=42)

ran_search = RandomizedSearchCV(
    clf,
    param_distributions=param_dist,
    n_iter=100,
    cv=10,
    n_jobs=-1,
    random_state=42,
    scoring='roc_auc'
)

ran_search.fit(X_train, Y_train)

print("Best hyperparameters found: ", ran_search.best_params_)
```

    Best hyperparameters found:  {'learning_rate': 1, 'max_depth': None, 'max_features': 'log2', 'min_samples_leaf': 7, 'min_samples_split': 4, 'n_estimators': 125}



```python
best_params = ran_search.best_params_
```


```python
final_model = GradientBoostingClassifier(**best_params)
final_model.fit(X_train, Y_train)
```




    GradientBoostingClassifier(learning_rate=1, max_depth=None, max_features='log2',
                               min_samples_leaf=7, min_samples_split=4,
                               n_estimators=125)




```python
Y_pred_2 = final_model.predict(X_test)

cm = confusion_matrix(Y_test, Y_pred_2)

train_acc_score_2 = final_model.score(X_train, Y_train)
test_acc_score_2 = final_model.score(X_test, Y_test)

plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt='g', cmap='Blues')
plt.xlabel('Predicted label')
plt.ylabel('True label')
plt.title(f'Testing Accuracy: {test_acc_score_2:.3f}\nTraining Accuracy: {train_acc_score_2:.3f}')
plt.show()
```


    
![png](output_173_0.png)
    


Hyperparameter tuning did not improve our model on the training set indicating that the model was still over fitting.

I looked at the feature importance below and removed some features that were low importance (below 5%) to see if they reduce overfitting. 


```python
importance_scores = best_model.feature_importances_
importance_scores
```




    array([1.14135506e-03, 7.33449006e-02, 9.22363875e-03, 2.23490565e-02,
           1.70461861e-02, 2.60876800e-04, 2.74364362e-06, 6.06960486e-02,
           1.11087000e-01, 2.23390235e-01, 5.61232271e-02, 6.10649507e-02,
           1.68234927e-02, 4.41376197e-02, 7.47024229e-02, 2.28606246e-01])




```python
feature_names = df3.columns[:-1]
```


```python
plt.barh(range(X_train.shape[1]), importance_scores)
plt.yticks(range(X_train.shape[1]), feature_names)
plt.xlabel('Importance score')
plt.ylabel('Feature')
plt.show()
```


    
![png](output_178_0.png)
    



```python
total_score = np.sum(importance_scores)
importance_percent = 100 * (importance_scores / total_score)
```


```python
feature_importance_df = pd.DataFrame({'feature_names': feature_names,
                                      'importance_scores': importance_scores,
                                      'importance_percent': importance_percent})
```


```python
feature_importance_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>feature_names</th>
      <th>importance_scores</th>
      <th>importance_percent</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Drug</td>
      <td>0.001141</td>
      <td>0.114136</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Age</td>
      <td>0.073345</td>
      <td>7.334490</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Sex</td>
      <td>0.009224</td>
      <td>0.922364</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Ascites</td>
      <td>0.022349</td>
      <td>2.234906</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Hepatomegaly</td>
      <td>0.017046</td>
      <td>1.704619</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Spiders</td>
      <td>0.000261</td>
      <td>0.026088</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Edema</td>
      <td>0.000003</td>
      <td>0.000274</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Bilirubin</td>
      <td>0.060696</td>
      <td>6.069605</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Cholesterol</td>
      <td>0.111087</td>
      <td>11.108700</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Albumin</td>
      <td>0.223390</td>
      <td>22.339023</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Copper</td>
      <td>0.056123</td>
      <td>5.612323</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Alk_Phos</td>
      <td>0.061065</td>
      <td>6.106495</td>
    </tr>
    <tr>
      <th>12</th>
      <td>SGOT</td>
      <td>0.016823</td>
      <td>1.682349</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Tryglicerides</td>
      <td>0.044138</td>
      <td>4.413762</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Platelets</td>
      <td>0.074702</td>
      <td>7.470242</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Prothrombin</td>
      <td>0.228606</td>
      <td>22.860625</td>
    </tr>
  </tbody>
</table>
</div>




```python
df4 = df3.drop(["Drug","Sex","Ascites","Hepatomegaly","Spiders","Edema","SGOT","Tryglicerides"],axis=1)
df4.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Bilirubin</th>
      <th>Cholesterol</th>
      <th>Albumin</th>
      <th>Copper</th>
      <th>Alk_Phos</th>
      <th>Platelets</th>
      <th>Prothrombin</th>
      <th>Stage</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>59.0</td>
      <td>14.5</td>
      <td>261.0</td>
      <td>2.60</td>
      <td>156.0</td>
      <td>1718.0</td>
      <td>190.0</td>
      <td>12.2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>56.0</td>
      <td>1.1</td>
      <td>302.0</td>
      <td>4.14</td>
      <td>54.0</td>
      <td>7394.8</td>
      <td>221.0</td>
      <td>10.6</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>70.0</td>
      <td>1.4</td>
      <td>176.0</td>
      <td>3.48</td>
      <td>210.0</td>
      <td>516.0</td>
      <td>151.0</td>
      <td>12.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>55.0</td>
      <td>1.8</td>
      <td>244.0</td>
      <td>2.54</td>
      <td>64.0</td>
      <td>6121.8</td>
      <td>183.0</td>
      <td>10.3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>38.0</td>
      <td>3.4</td>
      <td>279.0</td>
      <td>3.53</td>
      <td>143.0</td>
      <td>671.0</td>
      <td>136.0</td>
      <td>10.9</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
X= df4.drop(['Stage'], axis = 1)
Y = df4['Stage']
```


```python
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.30, random_state=42)
```


```python
ran_search.fit(X_train, Y_train)
```




    RandomizedSearchCV(cv=10, estimator=GradientBoostingClassifier(random_state=42),
                       n_iter=100, n_jobs=-1,
                       param_distributions={'learning_rate': [0.01, 0.05, 0.1, 0.5,
                                                              1],
                                            'max_depth': [2, 3, 4, 5, None],
                                            'max_features': ['sqrt', 'log2', None],
                                            'min_samples_leaf': <scipy.stats._distn_infrastructure.rv_frozen object at 0x7fdae2a8d630>,
                                            'min_samples_split': <scipy.stats._distn_infrastructure.rv_frozen object at 0x7fdae2efc390>,
                                            'n_estimators': <scipy.stats._distn_infrastructure.rv_frozen object at 0x7fdae2fe01d0>},
                       random_state=42, scoring='roc_auc')




```python
best_params = ran_search.best_params_
```


```python
final_model = GradientBoostingClassifier(**best_params)
final_model.fit(X_train, Y_train)
```




    GradientBoostingClassifier(max_depth=2, max_features='log2', min_samples_leaf=8,
                               min_samples_split=5, n_estimators=51)




```python
Y_pred_2 = final_model.predict(X_test)

cm = confusion_matrix(Y_test, Y_pred_2)

train_acc_score_2 = final_model.score(X_train, Y_train)
test_acc_score_2 = final_model.score(X_test, Y_test)

plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt='g', cmap='Blues')
plt.xlabel('Predicted label')
plt.ylabel('True label')
plt.title(f'Testing Accuracy: {test_acc_score_2:.3f}\nTraining Accuracy: {train_acc_score_2:.3f}')
plt.show()
```


    
![png](output_188_0.png)
    


Reducing the number of features helped reduce overfitting. Considering the size of the dataset, these are good accuracies with a testing accuracy of 76.6% and training accuracy of 86.5%.

## Conclusion

Gradient Boosting Classifier had the best score from the gridsearchcv but there was still a lot of overfitting. There were some issues with the dataset including it not having enough samples to reliably create an accurate model, class imbalance, and missing data. For example, having a small dataset can lead to overfitting because there isnt enough data to capture the underlying patterns. Addressing each of these steps can create noise or bias in the model leading to incorrect predictions. For example, having 25% of the dataset be missing for 9/16 of out final features can lead to a biased model when we address them.

Reducing the number of low importance features helped reduce overfitting. 

## References 

1. “Cirrhosis.” Mayo Clinic, Mayo Foundation for Medical Education and Research, 11 Feb. 2023, https://www.mayoclinic.org/diseases-conditions/cirrhosis/symptoms-causes/syc-20351487. 
2. “FASTSTATS - Chronic Liver Disease or Cirrhosis.” Centers for Disease Control and Prevention, Centers for Disease Control and Prevention, 17 Jan. 2023, https://www.cdc.gov/nchs/fastats/liver-disease.htm. 
3. Fedesoriano. “Cirrhosis Prediction Dataset.” Kaggle, 2 Aug. 2021, https://www.kaggle.com/datasets/fedesoriano/cirrhosis-prediction-dataset. 
4. Wiley Online Library. https://pathsocjournals.onlinelibrary.wiley.com/doi/epdf/10.1002/path.5471. 
5. Guy, Jennifer, and Marion G Peters. “Liver Disease in Women: The Influence of Gender on Epidemiology, Natural History, and Patient Outcomes.” Gastroenterology &amp; Hepatology, U.S. National Library of Medicine, Oct. 2013, https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3992057/. 
6. Perri GA. Ascites in patients with cirrhosis. Can Fam Physician. 2013 Dec;59(12):1297-9; e538-40. PMID: 24336542; PMCID: PMC3860926.
7. Mayo Clinic. “Enlarged Liver - Symptoms and Causes.” Mayo Clinic, 2018, www.mayoclinic.org/diseases-conditions/enlarged-liver/symptoms-causes/syc-20372167.
8. Samant H, Kothadia JP. Spider Angioma. [Updated 2023 Feb 12]. In: StatPearls [Internet]. Treasure Island (FL): StatPearls Publishing; 2023 Jan-. Available from: https://www.ncbi.nlm.nih.gov/books/NBK507818/
9. A. Kashani, C. Landaverde, V. Medici, L. Rossaro, Fluid retention in cirrhosis: pathophysiology and management, QJM: An International Journal of Medicine, Volume 101, Issue 2, February 2008, Pages 71–85, https://doi.org/10.1093/qjmed/hcm121
10. LiverTox: Clinical and Research Information on Drug-Induced Liver Injury [Internet]. Bethesda (MD): National Institute of Diabetes and Digestive and Kidney Diseases; 2012-. Cirrhosis. [Updated 2019 May 4]. Available from: https://www.ncbi.nlm.nih.gov/books/NBK548598/
11. High Cholesterol Leads to Long-Term Liver Scarring and Immune Cell Dysfunction in Lab Study | Keck School of Medicine of USC. 16 Sept. 2022, keck.usc.edu/high-cholesterol-leads-to-long-term-liver-scarring-and-immune-cell-dysfunction-in-lab-study/#:~:text=Excess%20cholesterol%20accelerates%20damage%20of.
12. Castro-Narro, Graciela, et al. “POSITION STATEMENT on the USE of ALBUMIN in LIVER CIRRHOSIS.” Annals of Hepatology, 10 May 2022, p. 100708, www.sciencedirect.com/science/article/pii/S1665268122000503?via%3Dihub, https://doi.org/10.1016/j.aohep.2022.100708. 
13. “Wilson’s Disease - Symptoms and Causes.” Mayo Clinic, www.mayoclinic.org/diseases-conditions/wilsons-disease/symptoms-causes/syc-20353251#:~:text=Scarring%20of%20the%20liver%20(cirrhosis. 
15. “Alkaline Phosphatase: Liver Function Test - Viral Hepatitis and Liver Disease.” Www.hepatitis.va.gov, www.hepatitis.va.gov/hcv/patient/diagnosis/labtests-alkaline-phosphatase.asp.
16. Chrostek L, Supronowicz L, Panasiuk A, Cylwik B, Gruszewska E, Flisiak R. The effect of the severity of liver cirrhosis on the level of lipids and lipoproteins. Clin Exp Med. 2014 Nov;14(4):417-21. doi: 10.1007/s10238-013-0262-5. PMID: 24122348; PMCID: PMC4213382.
17. Hana I. Lim, Adam Cuker; Thrombocytopenia and liver disease: pathophysiology and periprocedural management. Hematology Am Soc Hematol Educ Program 2022; 2022 (1): 296–302. doi: https://doi.org/10.1182/hematology.2022000408
18. U.S. Department of Veteran Affairs. “Prothrombin Time: Liver Function Test - Viral Hepatitis and Liver Disease.” Www.hepatitis.va.gov, www.hepatitis.va.gov/hcv/patient/diagnosis/labtests-prothrombin-time.asp#:~:text=When%20the%20PT%20is%20high.
19. Kazemi K, Geramizadeh B, Nikeghbalian S, Salahi H, Bahador A, Reza Nejatollahi SM, Dehghani SM, Dehghani M, Kakaei F, Malek-Hosseini SA. Effect of D-penicillamine on liver fibrosis and inflammation in Wilson disease. Exp Clin Transplant. 2008 Dec;6(4):261-3. PMID: 19338486.
